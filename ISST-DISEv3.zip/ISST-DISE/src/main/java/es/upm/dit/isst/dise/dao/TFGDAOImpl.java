package es.upm.dit.isst.dise.dao;

import java.util.List;

import com.googlecode.objectify.Key;

import es.upm.dit.isst.dise.model.TFG;

import static com.googlecode.objectify.ObjectifyService.ofy;

public class TFGDAOImpl implements DISEDAO {

	private static TFGDAOImpl instancia;
	private TFGDAOImpl() {
	}
	public static TFGDAOImpl getInstancia () {
		if ( instancia == null)
		instancia = new TFGDAOImpl ();
		return instancia;
	}
	
	@Override
	public TFG crearTFG(String autor, String titulo, String tutor, String secretario) {
		TFG tfg = new TFG(autor, titulo, tutor, secretario);
		ofy().save().entity(tfg).now();
		return tfg;
	}

	@Override
	public List<TFG> leerTodosTFG() {
		List<TFG> tfgs = ofy().load().type(TFG.class).list();
		return tfgs;
	}

	@Override
	public TFG leerPorAutor(String autor) {
		TFG tfg = ofy().load().type(TFG.class).filterKey(Key.create(TFG.class, autor)).first().now();
		return tfg;
	}

	@Override
	public List<TFG> leerPorTutor(String tutor) {
		List<TFG> tfgs = ofy().load().type(TFG.class).filter("tutor", tutor).list();
		return tfgs;
	}

	@Override
	public List<TFG> leerPorSecretario(String secretario) {
		List<TFG> tfgs = ofy().load().type(TFG.class).filter("secretario", secretario).list();
		return tfgs;
	}

	@Override
	public TFG actualizaTFG(TFG tfg) {
		ofy().save().entity(tfg).now();
		return tfg;
	}

	@Override
	public TFG borraTFG(TFG tfg) {
		ofy().delete().entity(tfg).now();
		return tfg;
	}

}
