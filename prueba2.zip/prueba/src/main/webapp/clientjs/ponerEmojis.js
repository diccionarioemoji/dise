/**
 * ponerEmojis.js
 */

function insertarEmoji(emoji){ 
    var campo = document.getElementById('campo');
    campo.focus()
    campoInicial= campo.innerHTML
    campo.innerHTML = campoInicial + '<img width="18px" height="18px" src='+emoji.src+'/>'; 
}

function insertarUnEmoji(emoji){ 
    var campo = document.getElementById('campo');
   // var dir = document.getElementById ("elegido").value
    campo.focus()
    campo.innerHTML = "<p>Traducciones del emoji:" +emoji.alt[0].traduccion+'<img width="25px" height="25px" src='+emoji.src+'/></p>';
    
} 

