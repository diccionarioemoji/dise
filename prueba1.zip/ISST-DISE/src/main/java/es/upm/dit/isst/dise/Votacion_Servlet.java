package es.upm.dit.isst.dise;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Votacion_Servlet extends HttpServlet {
	//public String seleccionado;
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String seleccionado = req.getParameter("escrito");
		
		String pulsado = req.getParameter("value");
		
		req.getSession().setAttribute("seleccionado", seleccionado);
		
		req.getSession().setAttribute("pulsado", pulsado);
		
		resp.sendRedirect("Votacion.jsp");
	}

//	@Override
//	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//		//DISEDAO dao = DISEDAOImpl.getInstancia();
//		
//		String seleccionado = req.getParameter("seleccionado");
//		//Emoji emoji = dao.leerEmoji(seleccionado);
//				
//		//ArrayList<Traduccion> array = new ArrayList<Traduccion>();
//
//		//array.addAll(emoji.getTraducciones());
//
//		req.getSession().setAttribute("seleccionado", seleccionado);
//
//		
//		RequestDispatcher view = req.getRequestDispatcher("Votacion.jsp");
//		view.forward(req, resp);
//		
//		//resp.sendRedirect("Votacion.jsp");
//	}
}
